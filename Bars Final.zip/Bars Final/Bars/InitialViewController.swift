//
//  InitialViewController.swift
//  Bars
//
//  Created by Swayam Barik on 8/6/16.
//  Copyright © 2016 Swayam Barik. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation


class InitialViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        dropTheBeat.layer.cornerRadius = 15
        viewRecordings.layer.cornerRadius = 15
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func unwindToFeed(segue: UIStoryboardSegue) {
       BackgroundMusic.player.pause()
    }
    @IBOutlet weak var dropTheBeat: UIButton!
    @IBOutlet weak var viewRecordings: UIButton!
}
