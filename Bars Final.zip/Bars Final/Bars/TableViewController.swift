//
//  TableViewController.swift
//  Bars
//
//  Created by Swayam Barik on 8/5/16.
//  Copyright © 2016 Swayam Barik. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

let reuseIdentifier = "recordingCell"
var file = NSURL()
var fileName = String()


class TableViewController: UITableViewController {
    
    var recordings = [NSURL]()
    var player:AVAudioPlayer!
    
    let messageComposer = MessageComposer()

    
    func completer(input: String, completion: (result:String) -> Void){
        let messageComposeVC = self.messageComposer.configuredMessageComposeViewController()
        completion(result: "Completed")
        presentViewController(messageComposeVC, animated: true, completion: nil)
    }
    
    func sendMessageCalled() {
        //ADD CODE HERE RANDAL
        // Make sure the device can send text messages
        if (self.messageComposer.canSendText()) {
            // Obtain a configured MFMessageComposeViewController
            
            
//            let messageComposeVC = self.messageComposer.configuredMessageComposeViewController()
//            
//            presentViewController(messageComposeVC, animated: true, completion: nil)
            
            completer("commands") {
                (result: String) in
                
                print("got back: \(result)")
                
            }
            
            
            
            // Present the configured MFMessageComposeViewController instance
            // Note that the dismissal of the VC will be handled by the messageComposer instance,
            // since it implements the appropriate delegate call-back
            
        } else {
            // Let the user know if his/her device isn't able to send text messages
             let errorAlert = UIAlertView(title: "Cannot Send Text Message", message: "Your device is not able to send text messages.", delegate: self, cancelButtonTitle: "OK")
              errorAlert.show()
            print("YOooooooo")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // set the recordings array
        listRecordings()
        
        
        
        
        
        let recognizer = UILongPressGestureRecognizer(target: self, action: "longPress:")
        recognizer.minimumPressDuration = 0.5 //seconds
        recognizer.delegate = self
        recognizer.delaysTouchesBegan = true
        self.tableView?.addGestureRecognizer(recognizer)
        
        let doubleTap = UITapGestureRecognizer(target:self, action:"doubleTap:")
        doubleTap.numberOfTapsRequired = 2
        doubleTap.numberOfTouchesRequired = 1
        doubleTap.delaysTouchesBegan = true
        self.tableView?.addGestureRecognizer(doubleTap)
    }
    
    /**
     Get the cell with which you interacted.
     */
    //    func getCell(rec:UIGestureRecognizer) -> UItableViewCell {
    //        var cell:UItableViewCell!
    //
    //        let p = rec.locationInView(self.tableView)
    //        let indexPath = self.tableView?.indexPathForItemAtPoint(p)
    //        if indexPath == nil {
    //            NSLog("couldn't find index path");
    //        } else {
    //            cell = self.tableView?.cellForItemAtIndexPath(indexPath!)
    //            NSLog("found cell at \(indexPath!.row)")
    //        }
    //        return cell
    //    }
    
    func doubleTap(rec:UITapGestureRecognizer) {
        if rec.state != .Ended {
            return
        }
        
        let p = rec.locationInView(self.tableView)
       
        if let indexPath = self.tableView.indexPathForRowAtPoint(p) {
            askToRename(indexPath.row)
        }
        
//        if let indexPath = self.tableView?.indexPathForItemAtPoint(p) {
//            askToRename(indexPath.row)
//        }
        
    }
    
    func longPress(rec:UISwipeGestureRecognizer) {
        if rec.state != .Ended {
            return
        }
        let p = rec.locationInView(self.tableView)
        
        if let indexPath = self.tableView.indexPathForRowAtPoint(p) {
            askToDelete(indexPath.row)
        }
//        if let indexPath = self.tableView?.indexPathForItemAtPoint(p) {
//            
//        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
     // Get the new view controller using [segue destinationViewController].
     // Pass the selected object to the new view controller.
     }
     */
    
    // MARK: UItableViewDataSource

    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.recordings.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier(reuseIdentifier, forIndexPath: indexPath) as! TableViewCell
        
        
        cell.label.text = recordings[indexPath.row].lastPathComponent
        
        return cell
    }
    
    // MARK: UItableViewDelegate
    
    override func tableView(tableView: UITableView, shouldHighlightRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
   
    
//    override func tableView(tableView: UITableView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
//        return true
//    }
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("selected \(recordings[indexPath.row].lastPathComponent)")
        
        //var cell = tableView.cellForItemAtIndexPath(indexPath)
        play(recordings[indexPath.row])
        print("HERE IS THE RECODINRG")
        
        file = recordings[indexPath.row]
        fileName = recordings[indexPath.row].absoluteString
        print(recordings[indexPath.row])
        shareButton.enabled = true
        
    }
    
    func play(url:NSURL) {
        print("playing \(url)")
        
        do {
            self.player = try AVAudioPlayer(contentsOfURL: url)
            player.prepareToPlay()
            player.volume = 1.0
            player.play()
        } catch let error as NSError {
            self.player = nil
            print(error.localizedDescription)
        } catch {
            print("AVAudioPlayer init failed")
        }
        
    }
    
    
    
    /*
     // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
     func tableView(tableView: UItableView!, shouldShowMenuForItemAtIndexPath indexPath: NSIndexPath!) -> Bool {
     return false
     }
     
     func tableView(tableView: UItableView!, canPerformAction action: String!, forItemAtIndexPath indexPath: NSIndexPath!, withSender sender: AnyObject!) -> Bool {
     return false
     }
     
     func tableView(tableView: UItableView!, performAction action: String!, forItemAtIndexPath indexPath: NSIndexPath!, withSender sender: AnyObject!) {
     
     }
     */
    
    
    
    func listRecordings() {
        
        let documentsDirectory = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        do {
            let urls = try NSFileManager.defaultManager().contentsOfDirectoryAtURL(documentsDirectory, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsHiddenFiles)
            self.recordings = urls.filter( { (name: NSURL) -> Bool in
                return name.lastPathComponent!.hasSuffix("m4a")
            })
            
        } catch let error as NSError {
            print(error.localizedDescription)
        } catch {
            print("something went wrong listing recordings")
        }
        
    }
    
    func askToDelete(row:Int) {
        let alert = UIAlertController(title: "Delete",
                                      message: "Delete Recording \(recordings[row].lastPathComponent!)?",
                                      preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .Default, handler: {action in
            print("yes was tapped \(self.recordings[row])")
            self.deleteRecording(self.recordings[row])
        }))
        alert.addAction(UIAlertAction(title: "No", style: .Default, handler: {action in
            print("no was tapped")
        }))
        self.presentViewController(alert, animated:true, completion:nil)
    }
    
    func askToRename(row:Int) {
        let recording = self.recordings[row]
        
        let alert = UIAlertController(title: "Rename",
                                      message: "Rename Recording \(recording.lastPathComponent!)?",
                                      preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .Default, handler: {[unowned alert] action in
            print("yes was tapped \(self.recordings[row])")
            if let textFields = alert.textFields{
                let tfa = textFields as [UITextField]
                let text = tfa[0].text
                let url = NSURL(fileURLWithPath: text!)
                self.renameRecording(recording, to: url)
            }
            }))
        alert.addAction(UIAlertAction(title: "No", style: .Default, handler: {action in
            print("no was tapped")
        }))
        alert.addTextFieldWithConfigurationHandler({textfield in
            textfield.placeholder = "Enter a filename"
            textfield.text = "\(recording.lastPathComponent!)"
        })
        self.presentViewController(alert, animated:true, completion:nil)
    }
    
    func renameRecording(from:NSURL, to:NSURL) {
        let documentsDirectory = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let toURL = documentsDirectory.URLByAppendingPathComponent(to.lastPathComponent!)
        
        print("renaming file \(from.absoluteString) to \(to) url \(toURL)")
        let fileManager = NSFileManager.defaultManager()
        fileManager.delegate = self
        do {
            try NSFileManager.defaultManager().moveItemAtURL(from, toURL: toURL)
        } catch let error as NSError {
            print(error.localizedDescription)
        } catch {
            print("error renaming recording")
        }
        dispatch_async(dispatch_get_main_queue(), {
            self.listRecordings()
            self.tableView?.reloadData()
        })
        
    }
    
    
    func deleteRecording(url:NSURL) {
        
        print("removing file at \(url.absoluteString)")
        let fileManager = NSFileManager.defaultManager()
        
        do {
            try fileManager.removeItemAtURL(url)
        } catch let error as NSError {
            print(error.localizedDescription)
        } catch {
            print("error deleting recording")
        }
        
        dispatch_async(dispatch_get_main_queue(), {
            self.listRecordings()
            self.tableView?.reloadData()
        })
    }
    
    @IBAction func shareThroughMessage(sender: AnyObject) {
        sendMessageCalled()
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            // handle delete (by removing the data from your array and updating the tableview)
           askToDelete(indexPath.row)
        }
    }
    
}

extension TableViewController: NSFileManagerDelegate {
    
    func fileManager(fileManager: NSFileManager, shouldMoveItemAtURL srcURL: NSURL, toURL dstURL: NSURL) -> Bool {
        
        print("should move \(srcURL) to \(dstURL)")
        return true
    }
    
}

extension TableViewController : UIGestureRecognizerDelegate {
    
}
