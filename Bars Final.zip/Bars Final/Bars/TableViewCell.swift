//
//  TableViewCell.swift
//  Bars
//
//  Created by Swayam Barik on 8/5/16.
//  Copyright © 2016 Swayam Barik. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

class TableViewCell: UITableViewCell{
    
    @IBOutlet weak var label: UILabel!
    
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//        let view = UIView(frame:self.frame)
//        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
//        view.backgroundColor = UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0)
//        view.layer.borderColor = UIColor.whiteColor().CGColor
//        view.layer.borderWidth = 4
//        self.selectedBackgroundView = view
//    }
}