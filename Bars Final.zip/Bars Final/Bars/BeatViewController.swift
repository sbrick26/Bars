//
//  BeatViewController.swift
//  Bars
//
//  Created by Swayam Barik on 8/8/16.
//  Copyright © 2016 Swayam Barik. All rights reserved.
//


import Foundation
import UIKit
import AVFoundation


class BeatViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        beat1.layer.cornerRadius = 15
        beat2.layer.cornerRadius = 15
        beat3.layer.cornerRadius = 15
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBOutlet weak var beat1: UIButton!
    @IBOutlet weak var beat2: UIButton!
    @IBOutlet weak var beat3: UIButton!
    
    
}
